<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheet/style.css">
    <script defer src="java/java.js"></script>
    <title>Hangman</title>
</head>
<body>
    <div id="center">
        <div id="galgje">
            <h1>Hangman</h1>
                <label for="">kies een woord:</label>
                <input type="password" name="woord" id="woord">
                <input type="button" onclick="galgje()" value="submit woord">
        </div>
    </div>
</body>
</html>