<?php
$documentName = "Bestevaer - calculator";
// ^ Naam van de pagina
include_once "include/head.inc.php";
include_once "include/list/boten.php"; 
// ^ Veel includes voor overzicht
?>

<div id="calccontent">

    <?php include_once "include/calc.inc.php"; ?>

</div>

<?php include_once "include/foot.inc.php"; ?>