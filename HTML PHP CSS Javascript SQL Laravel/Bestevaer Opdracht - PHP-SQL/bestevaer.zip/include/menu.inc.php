<div id="menu">
    <div id="menhead">
        <div id="name">
            <p>Bestevaer</p>
        </div>
    </div>
    <div id="menlower">

        <button class="menitem" onclick="window.location.href='botenlijst.php'">
            <p>Botenlijst</p>
        </button>

        <button class="menitem" onclick="window.location.href='calculator.php'">
            <p>Calculator</p>
        </button>

    </div>
</div>