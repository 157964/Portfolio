</body>
    <!-- Made by Joeri Smit -->
    <?php if($documentName == "Bestevaer - calculator") {
        include_once "phptojs.php";
          } 
    ?>
</html>