<?php
$documentName = "Bestevaer - bootlijst";
include_once "include/head.inc.php";
?>

<div id="content">
 <?php include_once "include/boten.inc.php" ?>
</div>

<?php
include_once "include/foot.inc.php";

?>